Instaleaza: npm i && npm run dev
