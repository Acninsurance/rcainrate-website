export default function Page(){ return <div style={{padding:20}}>Salut din rcainrate.eu</div>; }
